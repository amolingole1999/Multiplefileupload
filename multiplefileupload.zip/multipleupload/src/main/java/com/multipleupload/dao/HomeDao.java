package com.multipleupload.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.multipleupload.model.Student;

@Repository
public class HomeDao 
{
	@Autowired 
	SessionFactory sft;
	
	public List<Student>getdao()
	{
		Session s=sft.openSession();
		Criteria crit=s.createCriteria(Student.class);
		List<Student> gd=crit.list();
		return gd;
	}
	public List<Student>postdao(Student stu)
	{
		Session s=sft.openSession();
		Transaction tra=s.beginTransaction();
		s.save(stu);
		tra.commit();
		List<Student>pd=getdao();
		return pd;
	}
	public List<Student>putdao(Student stu)
	{
		Session s=sft.openSession();
		Transaction tra=s.beginTransaction();
		s.update(stu);
		tra.commit();
		List<Student>pd=getdao();
		return pd;
	}
	public List<Student>deldao(int id)
	{
		Session s=sft.openSession();
		Student st=s.load(Student.class, id);
		Transaction tra=s.beginTransaction();
		s.delete(st);
		tra.commit();
		List<Student>dd=getdao();
		return dd;
	}
}

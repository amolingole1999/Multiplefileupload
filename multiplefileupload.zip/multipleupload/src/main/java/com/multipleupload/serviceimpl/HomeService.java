package com.multipleupload.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.multipleupload.dao.HomeDao;
import com.multipleupload.model.Student;

@Service
public class HomeService 
{	
	@Autowired
	HomeDao db;
	
	public List<Student>getser()
	{
		List<Student> gs=db.getdao();
		return gs;
	}
	public List<Student>postser(Student stu)
	{
		List<Student> ps=db.postdao(stu);
		return ps;
	}
	public List<Student>putser(Student stu)
	{
		List<Student> ps=db.putdao(stu);
		return ps;
	}
	public List<Student>delser(int id)
	{
		List<Student> ds=db.deldao(id);
		return null;
	}
}

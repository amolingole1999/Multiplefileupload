package com.multipleupload.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.multipleupload.model.Student;
import com.multipleupload.serviceimpl.HomeService;

@RestController
public class HomeController 
{
	@Autowired
	HomeService ser;
	
	@GetMapping("getdata")
	List<Student>getcon()
	{
		List<Student> gc=ser.getser();
		return gc;
	}
	@PostMapping("postdata")
	List<Student>postcon(@RequestBody Student stu)
	{
		List<Student> pc=ser.postser(stu);
		return pc;
	}
	@PutMapping("putdata")
	List<Student>putcon(@RequestBody Student stu)
	{
		List<Student> pt=ser.putser(stu);
		return pt;
	}
	@DeleteMapping("deletedata/{id}")
	List<Student>delcon(@PathVariable int id)
	{
		List<Student>dc=ser.delser(id);
		return null;
	}
}

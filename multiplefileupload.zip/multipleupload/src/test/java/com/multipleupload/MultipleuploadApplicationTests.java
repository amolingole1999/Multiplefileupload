package com.multipleupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipleuploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
